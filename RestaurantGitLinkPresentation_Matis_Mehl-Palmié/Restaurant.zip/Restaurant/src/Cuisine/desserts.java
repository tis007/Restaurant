package Cuisine;

public class desserts extends Plat {

	public desserts(int id, String name, int number) {
		super(id, name, number);
	}

}
