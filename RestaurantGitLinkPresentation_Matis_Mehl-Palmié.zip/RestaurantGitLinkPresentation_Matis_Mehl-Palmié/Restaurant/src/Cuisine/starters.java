package Cuisine;

public class starters extends Plat {

	public starters(int id, String name, int number) {
		super(id, name, number);
	}

}
