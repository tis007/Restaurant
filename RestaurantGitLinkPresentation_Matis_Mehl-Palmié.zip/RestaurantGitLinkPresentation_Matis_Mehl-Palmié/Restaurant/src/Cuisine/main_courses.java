package Cuisine;

public class main_courses extends Plat {

	public main_courses(int id, String name, int number) {
		super(id, name, number);
	}

}
